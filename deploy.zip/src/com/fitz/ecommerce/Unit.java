package com.fitz.ecommerce;

public enum Unit { POUND, LITRE, EACH, DOZEN, CASE}

