

			java -version
			java -cp bin com.fitz.main.CartDemo
		