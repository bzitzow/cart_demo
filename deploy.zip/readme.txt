
build date : 20180702
repo: github.com/rustyrabbit/cart_demo
Simple ecommerce cart demo. 
To execute from the command line:
cd to deploy dir
Windows, execute run_cart_demo.bat
Mac OS X, Linux, execute run_cart_demo.sh
Make sure your $PATH sys variable points to a JRE
Coded to Java 8 compliance on Mac OS X High Sierra
Tested on Windows 10
TODO: Fix the classpath problem in the jar to make it runnable
			

		